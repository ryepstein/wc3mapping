SublimeText-JASS
================

Syntax definition for JASS (Warcraft 3) - Includes cJASS &amp; vJASS

* Works on SublimeText 2 & 3 *

How to install? (SublimeText 2)
===============================

* Preferences -> Browse Packages...
* Create a new folder with the name JASS (Warcraft 3)
* Drop all of the files there
* Restart SublimeText
* Done!

How to install? (SublimeText 3)
===============================

* Go to your/sublime/text/3/installation/folder/Packages
* Paste there the file JASS.SUBLIME-PACKAGE
* Done!